import tkinter as tk
from tkinter import *
from tkinter import messagebox
from tkinter import font as tkfont
import json
import os
from datetime import datetime

# Define the path to the JSON files
DATA_FILE = 'tasks.json'
USER_FILE = 'users.json'

class TaskManager:
    @staticmethod
    def load_tasks():
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r') as file:
                try:
                    data = json.load(file)
                    return [
                        {
                            "title": item.get("title", "Untitled"),
                            "task": item["task"] if isinstance(item, dict) else item,
                            "due_date": item.get("due_date", "No due date"),
                            "done": item.get("done", False)
                        }
                        for item in data
                    ]
                except json.JSONDecodeError:
                    return []
        return []


    @staticmethod
    def save_tasks(tasks):
        with open(DATA_FILE, 'w') as file:
            json.dump(tasks, file)

class UserManager:
    @staticmethod
    def load_users():
        if os.path.exists(USER_FILE):
            with open(USER_FILE, 'r') as file:
                try:
                    data = json.load(file)
                    if isinstance(data, dict):
                        return data
                    else:
                        return {}
                except json.JSONDecodeError:
                    return {}
        return {}


    @staticmethod
    def save_users(users):
        with open(USER_FILE, 'w') as file:
            json.dump(users, file)

    @staticmethod
    def register(username, password):
        users = UserManager.load_users()
        if username in users:
            return False  # Username already exists
        users[username] = password
        UserManager.save_users(users)
        return True

    @staticmethod
    def validate_login(username, password):
        users = UserManager.load_users()
        return users.get(username) == password

class ToDoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List")
        self.root.geometry("450x550")  # Tăng kích thước cửa sổ
        self.root.configure(bg='#7469B6')
        self.semibold_font = tkfont.Font(family="Helvetica", size=14, weight="bold")  # Font lớn hơn

        # icon
        Image_icon = PhotoImage(file="Image/task.png")
        root.iconphoto(False, Image_icon)

        self.tasks = TaskManager.load_tasks()
        self.role = None

        self.frame_login = tk.Frame(root, bg='#7469B6')
        self.frame_main = tk.Frame(root, bg='#7469B6')
        self.frame_tasks = tk.Frame(self.frame_main)

        self.listbox_tasks = tk.Listbox(self.frame_tasks, height=10, width=50)
        self.scrollbar_tasks = tk.Scrollbar(self.frame_tasks, bg='#F9F5F6')
        self.entry_task = tk.Entry(self.frame_main, width=50)

        self.entry_username = tk.Entry(self.frame_login, width=35, font=self.semibold_font)
        self.entry_password = tk.Entry(self.frame_login, show='*', width=35, font=self.semibold_font)

        self.create_login_ui()
        self.create_main_ui()

        self.show_login_window()


    def create_login_ui(self):
        self.frame_login.pack(pady=40)  # Lùi cả khối login xuống dưới

        # Tạo frame con để sắp xếp label và entry theo grid
        form_frame = tk.Frame(self.frame_login, bg='#7469B6')
        form_frame.pack()

        # Username
        tk.Label(form_frame, text="Username:", bg='#7469B6', fg='white', font=self.semibold_font)\
            .grid(row=0, column=0, padx=10, pady=10, sticky='e')
        self.entry_username = tk.Entry(form_frame, width=30, font=self.semibold_font)
        self.entry_username.grid(row=0, column=1, padx=10, pady=10)

        # Password
        tk.Label(form_frame, text="Password:", bg='#7469B6', fg='white', font=self.semibold_font)\
            .grid(row=1, column=0, padx=10, pady=10, sticky='e')
        self.entry_password = tk.Entry(form_frame, show='*', width=30, font=self.semibold_font)
        self.entry_password.grid(row=1, column=1, padx=10, pady=10)

        # Frame chứa các nút
        button_frame = tk.Frame(self.frame_login, bg='#7469B6')
        button_frame.pack(pady=20)

        tk.Button(button_frame, text="Login", command=self.login,
                bg='white', fg='#00215E', font=self.semibold_font, width=15).pack(pady=5)
        tk.Button(button_frame, text="Register", command=self.register,
                bg='white', fg='#00215E', font=self.semibold_font, width=15).pack(pady=5)
        tk.Button(button_frame, text="Continue as guest", command=self.continue_as_user,
                bg='white', fg='#00215E', font=self.semibold_font, width=20).pack(pady=10)


    def create_main_ui(self):
        self.frame_tasks.pack(pady=10)
        self.listbox_tasks.pack(side=tk.LEFT, fill=tk.BOTH)
        self.scrollbar_tasks.pack(side=tk.RIGHT, fill=tk.BOTH)
        self.listbox_tasks.config(yscrollcommand=self.scrollbar_tasks.set)
        self.scrollbar_tasks.config(command=self.listbox_tasks.yview)

        self.entry_title = tk.Entry(self.frame_main, width=50)
        self.set_placeholder(self.entry_title, "Enter task title...")
        self.entry_title.pack(pady=5)

        self.entry_task.pack(pady=10)
        self.set_placeholder(self.entry_task, "Enter your todo here...")
        

        self.entry_due = tk.Entry(self.frame_main, width=50)
        self.set_placeholder(self.entry_due, "Enter due date (DD-MM-YYYY)...")
        self.entry_due.pack(pady=5)


        self.create_button_with_border(self.frame_main, "Add Task", self.add_task, '#FF3EA5').pack(pady=5)
        self.create_button_with_border(self.frame_main, "Update Task", self.update_task, '#FF3EA5').pack(pady=5)
        self.create_button_with_border(self.frame_main, "Delete Task", self.delete_task, '#EE4266').pack(pady=5)
        self.create_button_with_border(self.frame_main, "Mark Task as Done", self.mark_task_done, '#54B435').pack(pady=5)
        self.create_button_with_border(self.frame_main, "Logout", self.logout, '#FF3EA5').pack(pady=5)

    def create_button_with_border(self, parent, text, command, bg_color):
        frame = tk.Frame(parent, background='white', bd=1)
        button = tk.Button(frame, text=text, command=command, bg=bg_color, fg='white',
                           font=self.semibold_font, width=25, highlightthickness=0, bd=0)
        button.pack(padx=1, pady=1)
        return frame

    def login(self):
        username = self.entry_username.get()
        password = self.entry_password.get()
        if username == "" or password == "":
            messagebox.showwarning("Input Error", "Please enter both username and password.")
            return
        if UserManager.validate_login(username, password):
            self.role = 'admin' if username == "admin" else 'user'
            self.show_main_window()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password.")

    def register(self):
        username = self.entry_username.get()
        password = self.entry_password.get()
        if username == "" or password == "":
            messagebox.showwarning("Input Error", "Please enter both username and password.")
            return
        if UserManager.register(username, password):
            messagebox.showinfo("Register Success", "Account created successfully. You can now login.")
        else:
            messagebox.showwarning("Register Failed", "Username already exists.")

    def continue_as_user(self):
        self.role = 'user'
        self.show_main_window()

    def logout(self):
        self.role = None
        self.entry_username.delete(0, tk.END)
        self.entry_password.delete(0, tk.END)
        self.show_login_window()

    def show_login_window(self):
        self.frame_login.pack()
        self.frame_main.pack_forget()

    def show_main_window(self):
        self.frame_login.pack_forget()
        self.frame_main.pack()
        self.refresh_task_list()

    def add_task(self):
        title = self.entry_title.get()
        task = self.entry_task.get()
        due_date_input = self.entry_due.get()

        if not title or title == "Enter task title...":
            messagebox.showwarning("Input Error", "Please enter a title.")
            return
        if not task or task == "Enter your todo here...":
            messagebox.showwarning("Input Error", "Please enter a task.")
            return
        if not due_date_input or due_date_input == "Enter due date (DD-MM-YYYY)...":
            messagebox.showwarning("Input Error", "Please enter a due date.")
            return

        try:
            # Parse input (must be in DD-MM-YYYY format)
            date_obj = datetime.strptime(due_date_input, "%d-%m-%Y")
            due_date = date_obj.strftime("%d-%m-%Y")  # Format again to ensure valid format
        except ValueError:
            messagebox.showerror("Date Format Error", "Please enter the date in DD-MM-YYYY format.")
            return

        self.tasks.append({
            "title": title,
            "task": task,
            "due_date": due_date,
            "done": False
        })
        TaskManager.save_tasks(self.tasks)
        self.refresh_task_list()

        self.entry_title.delete(0, tk.END)
        self.entry_task.delete(0, tk.END)
        self.entry_due.delete(0, tk.END)


    def update_task(self):
        if self.role != 'admin':
            messagebox.showwarning("Permission Error", "You do not have permission to update tasks.")
            return
        selected_task_index = self.listbox_tasks.curselection()
        if selected_task_index:
            index = selected_task_index[0]
            new_title = self.entry_title.get()
            new_task = self.entry_task.get()
            new_due_input = self.entry_due.get()
            try:
                due_date_obj = datetime.strptime(new_due_input, "%Y-%m-%d")
                new_due = due_date_obj.strftime("%d-%m-%Y")
            except ValueError:
                messagebox.showwarning("Date Format Error", "Please enter the due date in format YYYY-MM-DD.")
                return


            if new_title and new_task and new_due:
                self.tasks[index]["title"] = new_title
                self.tasks[index]["task"] = new_task
                self.tasks[index]["due_date"] = new_due
                TaskManager.save_tasks(self.tasks)
                self.refresh_task_list()
                self.entry_title.delete(0, tk.END)
                self.entry_task.delete(0, tk.END)
                self.entry_due.delete(0, tk.END)
            else:
                messagebox.showwarning("Input Error", "Please enter all fields.")
        else:
            messagebox.showwarning("Selection Error", "Please select a task.")


    def delete_task(self):
        if self.role != 'admin':
            messagebox.showwarning("Permission Error", "You do not have permission to delete tasks.")
            return
        selected_task_index = self.listbox_tasks.curselection()
        if selected_task_index:
            task = self.tasks[selected_task_index[0]]["task"]
            if messagebox.askyesno("Confirm Delete", f"Do you want to delete the task: {task}?"):
                del self.tasks[selected_task_index[0]]
                self.refresh_task_list()
                TaskManager.save_tasks(self.tasks)
        else:
            messagebox.showwarning("Selection Error", "Please select a task to delete.")

    def mark_task_done(self):
        selected_task_index = self.listbox_tasks.curselection()
        if selected_task_index:
            self.tasks[selected_task_index[0]]["done"] = True
            self.refresh_task_list()
            TaskManager.save_tasks(self.tasks)
        else:
            messagebox.showwarning("Selection Error", "Please select a task to mark as done.")

    def refresh_task_list(self):
        self.listbox_tasks.delete(0, tk.END)
        for task in self.tasks:
            display = f"[{'✔' if task.get('done') else ' '}] {task.get('title', '')} - {task.get('task', '')} (Due: {task.get('due_date', '')})"
            self.listbox_tasks.insert(tk.END, display)


    def set_placeholder(self, entry, placeholder):
        entry.insert(0, placeholder)
        entry.bind("<FocusIn>", lambda event: self.clear_placeholder(entry, placeholder))
        entry.bind("<FocusOut>", lambda event: self.add_placeholder(entry, placeholder))

    def clear_placeholder(self, entry, placeholder):
        if entry.get() == placeholder:
            entry.delete(0, tk.END)

    def add_placeholder(self, entry, placeholder):
        if entry.get() == "":
            entry.insert(0, placeholder)

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoApp(root)
    root.mainloop()
